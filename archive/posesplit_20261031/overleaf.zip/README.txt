OVERLEAF PACKAGE

Select draft.tex as the main file. Use pdfLaTeX and BibTeX.
This archive contains the manuscript, identical bibliography aliases, and every referenced figure.
Repository: https://github.com/Saurav-K-Aryal/posesplit-pilot

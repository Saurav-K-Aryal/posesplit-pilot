EventOwner manuscript source, November 1, 2026.
Upload draft.tex, refs.bib and figures/ to Overleaf. Select draft.tex as the main document. Uses the standard ACM acmart manuscript single-column class and BibTeX. references.bib is an identical alias for convenience. The historical PoseSplit source package is archived separately in the repository.
